package com.example.prijal2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
