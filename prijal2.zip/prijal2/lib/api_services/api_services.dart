import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:prijal2/login/login_model.dart';
import 'package:dio/dio.dart' ;
import 'package:prijal2/tree/tree_model.dart';
class ApiServices{
  final Dio dio= Dio();
  Future<login> Login(String email, String password) async{
    try{
      final respo= await http.post(
          Uri.parse("https://www.anniecabs.com/LJ/index.php/api/login"),
        body:{
            "Email":email,
            "Password":password,
        }
      );
      if(respo.statusCode==200 || respo.statusCode==201){
        final jsonData= jsonDecode(respo.body);
        final userValue= login.fromJson(jsonData);
        return userValue;
      }else{
        throw Exception("Error!");
      }
    }catch(e){
      print(e);
      throw Exception("Error!");
    }
  }

  Future<tree> Tree() async{
    try{
      final respo= await dio.get("https://www.anniecabs.com/LJ/index.php/api/get_tree_plant",);


      if(respo.statusCode==200) {
        final user_value= tree.fromJson(respo.data);
        return user_value;
      }else {
       throw Exception("Error!");
      }
    }catch(e){
      print(e);
      throw Exception("Error!");
    }
  }
}