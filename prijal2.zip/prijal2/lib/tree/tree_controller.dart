import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:prijal2/api_services/api_services.dart';
import 'package:prijal2/tree/tree_model.dart';

class TreeController extends GetxController{
  ApiServices api=ApiServices();
  final treeData=<tree>{}.obs;
  RxList treeDataList=<TreePlant>[].obs;
  RxBool isLoading= false.obs;

  Future<void> TreeCount() async{
    isLoading.value=true;
    final respo= await api.Tree();
    if(respo.responseCode.toString()=="1"){

      treeDataList.value = respo.treePlant ?? [];
      isLoading.value=false;

    }else{
      Get.snackbar("Error",
          respo.message.toString(),
          backgroundColor: Colors.red
      );
    }

  }
}